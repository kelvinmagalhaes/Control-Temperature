/*
 * File: Controle_principal_types.h
 *
 * Code generated for Simulink model 'Controle_principal'.
 *
 * Model version                  : 1.33
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * TLC version                    : 8.8 (Jan 20 2015)
 * C/C++ source code generated on : Sat Apr 13 21:36:20 2019
 *
 * Target selection: realtime.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Controle_principal_types_h_
#define RTW_HEADER_Controle_principal_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Parameters (auto storage) */
typedef struct P_Controle_principal_T_ P_Controle_principal_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Controle_principal_T RT_MODEL_Controle_principal_T;

#endif                                 /* RTW_HEADER_Controle_principal_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
